# Bug Bounty AI Agent

AI-powered bug bounty hunting platform with:
- 17 scan types (recon, xss, ssrf, sqlmap, etc.)
- Kanban workflow (8 stages)
- CVSS enrichment via NVD API
- EPSS probability scoring
- Automated Kali Linux integration
- JWT authentication
- Live streaming output via SSE

## Quick Start

```bash
cp .env.template .env
# Edit .env with your settings
docker compose up -d
```

Access: http://localhost:3001

## Requirements

- Docker + Docker Compose
- Kali Linux container (optional, for local scanning)
- 4GB+ RAM recommended
