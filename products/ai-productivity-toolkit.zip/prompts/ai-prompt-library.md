# AI Productivity Toolkit - Prompt Library

## Category: Content Creation

### Blog Post Generator
Prompt: "Write a comprehensive blog post about [TOPIC] targeting [AUDIENCE].
Include SEO keywords: [KEYWORDS]. Tone: [FORMAL/CASUAL]. Length: [WORDS] words."

### Social Media Caption Creator
Prompt: "Create [NUMBER] social media captions for [PLATFORM] about [TOPIC].
Include relevant hashtags and a call to action."

### Email Newsletter
Prompt: "Write a weekly newsletter update about [TOPIC].
Include: subject line (5 options), main content (300 words), CTA."

## Category: Workflow Automation

### Email Triage
Prompt: "Classify these emails into: Urgent/Important/Reading/Spam.
For each urgent email, draft a 2-sentence response."

### Meeting Notes Summarizer
Prompt: "Summarize this meeting transcript.
Key decisions, action items (with owners), and next steps."

### Task Priority Matrix
Prompt: "Analyze these tasks and sort by: Impact (high/medium/low) and
Effort (high/medium/low). Recommend top 5 priorities."

## Category: Business Development

### Cold Email Generator
Prompt: "Write a cold email for [TARGET_COMPANY] offering [SERVICE].
Personalization hook: [HOOK]. Tone: professional but warm."

### Competitor Analysis
Prompt: "Analyze [COMPETITOR]'s strengths and weaknesses relative to [OUR_BUSINESS].
Focus on: product, pricing, marketing channels, customer reviews."

### Value Proposition Canvas
Prompt: "Help me define the value proposition for [PRODUCT/SERVICE].
Customer jobs, pains, gains. Then map to our product features."
