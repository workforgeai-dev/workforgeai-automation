# NEXUS One-Click Deploy

Deploy your own private AI agent infrastructure in minutes.

## What's included

- Redis cache layer
- PostgreSQL database
- NEXUS API server
- Docker Compose orchestration

## Requirements

- Docker + Docker Compose
- 4GB+ RAM
- Ollama (optional, for local LLMs)

## Quick Start

1. Copy `.env.template` to `.env` and edit
2. Run `bash setup.sh`
3. Access the API at `http://localhost:8000`

## Pricing

This is the self-hosted version. No subscriptions, no cloud dependencies.
