#!/bin/bash
set -e
echo "=== NEXUS One-Click Deploy ==="
echo ""

# Check prerequisites
command -v docker >/dev/null 2>&1 || { echo "Error: Docker is required. Install at https://docs.docker.com/get-docker/"; exit 1; }
command -v docker compose >/dev/null 2>&1 || { echo "Error: Docker Compose is required."; exit 1; }

# Setup .env
if [ ! -f .env ]; then
    cp .env.template .env
    echo "[!] Please edit .env with your configuration, then run: docker compose up -d"
else
    echo "[+] .env found"
fi

# Start services
echo "[+] Starting NEXUS services..."
docker compose up -d

echo ""
echo "=== NEXUS is running ==="
echo "API: http://localhost:8000"
echo "Health: http://localhost:8000/health"
echo ""
echo "Run 'docker compose logs -f' to see logs."
